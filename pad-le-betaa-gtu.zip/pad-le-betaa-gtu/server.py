#!/usr/bin/env python3
"""Pad Le Betaa GTU - dependency-free full-stack server (Python 3.8+, SQLite)."""
import os, re, json, time, base64, secrets, hashlib, hmac, sqlite3, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

B = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('DATA_DIR', os.path.join(B, 'data'))
UP = os.path.join(DATA, 'uploads')
STATIC = os.path.join(B, 'static')
os.makedirs(UP, exist_ok=True)
SECURE = os.environ.get('SECURE_COOKIE') == '1'
TYPES = ('free', 'premium', 'pyq', 'mimp')
SK = ('banner_text', 'banner_on', 'upi_id', 'upi_name', 'email', 'youtube', 'telegram')
MAXB = 45 * 1024 * 1024
FAILS = {}


class Err(Exception):
    def __init__(s, code, msg): s.code, s.msg = code, msg


def db():
    c = sqlite3.connect(os.path.join(DATA, 'app.db'))
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c


def hp(pw, salt): return hashlib.pbkdf2_hmac('sha256', pw.encode(), salt, 200000).hex()
def th(t): return hashlib.sha256(t.encode()).hexdigest()


def init():
    c = db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,salt BLOB,pw TEXT,is_admin INTEGER DEFAULT 0,created INTEGER);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,uid INTEGER REFERENCES users(id) ON DELETE CASCADE,exp INTEGER);
    CREATE TABLE IF NOT EXISTS materials(id INTEGER PRIMARY KEY,semester INTEGER,subject TEXT,title TEXT,type TEXT,price INTEGER DEFAULT 0,link TEXT,file TEXT,created INTEGER);
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,uid INTEGER REFERENCES users(id) ON DELETE CASCADE,mid INTEGER REFERENCES materials(id) ON DELETE CASCADE,amount INTEGER,txn TEXT,status TEXT DEFAULT 'pending',created INTEGER);
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
    ''')
    if not c.execute('SELECT 1 FROM users WHERE is_admin=1').fetchone():
        em = os.environ.get('ADMIN_EMAIL', 'admin@padlebetaa.local').lower()
        pw = os.environ.get('ADMIN_PASSWORD') or secrets.token_urlsafe(10)
        s = secrets.token_bytes(16)
        c.execute('INSERT INTO users(name,email,salt,pw,is_admin,created) VALUES(?,?,?,?,1,?) '
                  'ON CONFLICT(email) DO UPDATE SET is_admin=1,salt=excluded.salt,pw=excluded.pw',
                  ('Admin', em, s, hp(pw, s), int(time.time())))
        print(f'\n*** ADMIN CREATED -> email: {em}   password: {pw} ***\n')
    c.commit(); c.close()


def settings(c): return {r['k']: r['v'] for r in c.execute('SELECT k,v FROM settings')}


def pub_settings(c):
    s = settings(c)
    d = {k: s.get(k, '') for k in SK}
    d['qr'] = bool(s.get('qr_mime'))
    return d


def need_int(v, lo, hi, msg):
    try: v = int(v)
    except (TypeError, ValueError): raise Err(400, msg)
    if not lo <= v <= hi: raise Err(400, msg)
    return v


def clean(b):
    sem = need_int(b.get('semester'), 1, 8, 'Semester must be 1-8')
    sub = str(b.get('subject', '')).strip()[:80]
    title = str(b.get('title', '')).strip()[:150]
    typ = b.get('type')
    if not sub or not title or typ not in TYPES: raise Err(400, 'Subject, title and type are required')
    price = 0
    if typ == 'premium':
        price = need_int(b.get('price') or 0, 1, 100000, 'Premium notes need a price (₹1 or more)')
    link = str(b.get('link') or '').strip()[:600]
    if link and not re.match(r'https?://\S+$', link, re.I): raise Err(400, 'Link must start with http:// or https://')
    return sem, sub, title, typ, price, link


def img_ok(raw, kind):
    if kind == 'pdf': return raw.startswith(b'%PDF')
    if raw.startswith(b'\x89PNG'): return 'image/png'
    if raw.startswith(b'\xff\xd8'): return 'image/jpeg'
    if raw[:4] == b'RIFF' and raw[8:12] == b'WEBP': return 'image/webp'
    return None


def dec(b64, limit):
    try: raw = base64.b64decode(b64, validate=True)
    except Exception: raise Err(400, 'Bad file data')
    if len(raw) > limit: raise Err(400, 'File too large')
    return raw


def save_pdf(b64):
    raw = dec(b64, 30 * 1024 * 1024)
    if not img_ok(raw, 'pdf'): raise Err(400, 'Only PDF files up to 30 MB are allowed')
    n = secrets.token_hex(12) + '.pdf'
    with open(os.path.join(UP, n), 'wb') as f: f.write(raw)
    return n


def rm(n):
    if n:
        try: os.remove(os.path.join(UP, os.path.basename(n)))
        except OSError: pass


def allowed(c, u, m):
    if m['type'] != 'premium' or u['is_admin']: return True
    return c.execute("SELECT 1 FROM payments WHERE uid=? AND mid=? AND status='approved'", (u['id'], m['id'])).fetchone() is not None


class H(BaseHTTPRequestHandler):
    server_version = 'PLB'
    def log_message(self, *a): pass

    def send(self, code, body=b'', ct='application/json', extra=()):
        if not isinstance(body, bytes): body = json.dumps(body).encode()
        self.send_response(code)
        hd = [('Content-Type', ct), ('Content-Length', str(len(body))), ('X-Content-Type-Options', 'nosniff'),
              ('X-Frame-Options', 'DENY'), ('Referrer-Policy', 'same-origin'),
              ('Cache-Control', 'no-store' if ct == 'application/json' or code != 200 else 'no-cache')]
        for k, v in hd + list(extra): self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)

    def cookie(self, n):
        for p in self.headers.get('Cookie', '').split(';'):
            k, _, v = p.strip().partition('=')
            if k == n: return v

    def user(self, c):
        t = self.cookie('sid')
        if not t: return None
        return c.execute('SELECT u.id,u.name,u.email,u.is_admin FROM sessions s JOIN users u ON u.id=s.uid '
                         'WHERE s.token=? AND s.exp>?', (th(t), int(time.time()))).fetchone()

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        if n > MAXB: raise Err(413, 'Request too large')
        if 'application/json' not in self.headers.get('Content-Type', ''): raise Err(415, 'JSON required')
        try: d = json.loads(self.rfile.read(n) or b'{}')
        except ValueError: raise Err(400, 'Bad JSON')
        if not isinstance(d, dict): raise Err(400, 'Bad JSON')
        return d

    def ck(self, val, age):
        sec = '; Secure' if SECURE or self.headers.get('X-Forwarded-Proto') == 'https' else ''
        return [('Set-Cookie', f'sid={val}; Path=/; HttpOnly; SameSite=Lax; Max-Age={age}{sec}')]

    def login_as(self, c, uid):
        t = secrets.token_urlsafe(32)
        c.execute('DELETE FROM sessions WHERE exp<?', (int(time.time()),))
        c.execute('INSERT INTO sessions VALUES(?,?,?)', (th(t), uid, int(time.time()) + 30 * 86400)); c.commit()
        u = c.execute('SELECT id,name,email,is_admin FROM users WHERE id=?', (uid,)).fetchone()
        self.send(200, {'user': dict(u)}, extra=self.ck(t, 30 * 86400))

    def handle_any(self, m):
        try:
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            c = db()
            try:
                if u.path.startswith('/api/'): self.api(m, u.path[5:].strip('/'), q, c)
                elif m == 'GET': self.static(u.path, c)
                else: raise Err(404, 'Not found')
            finally: c.close()
        except Err as e: self.send(e.code, {'error': e.msg})
        except Exception as e:
            print('ERROR', repr(e)); self.send(500, {'error': 'Server error'})

    def do_GET(self): self.handle_any('GET')
    def do_POST(self): self.handle_any('POST')
    def do_PUT(self): self.handle_any('PUT')
    def do_DELETE(self): self.handle_any('DELETE')

    def static(self, p, c):
        if p.startswith('/files/'):
            u = self.user(c)
            if not u: raise Err(401, 'Login required')
            m = c.execute('SELECT * FROM materials WHERE id=?', (p[7:],)).fetchone()
            if not m or not m['file']: raise Err(404, 'Not found')
            if not allowed(c, u, m): raise Err(403, 'Premium access required')
            with open(os.path.join(UP, os.path.basename(m['file'])), 'rb') as f: raw = f.read()
            fn = re.sub(r'[^A-Za-z0-9_-]+', '_', m['title'])[:60] or 'notes'
            return self.send(200, raw, 'application/pdf', [('Content-Disposition', f'inline; filename="{fn}.pdf"')])
        if p == '/qr':
            s = settings(c)
            fp = os.path.join(DATA, 'qr.bin')
            if not s.get('qr_mime') or not os.path.exists(fp): raise Err(404, 'No QR')
            with open(fp, 'rb') as f: return self.send(200, f.read(), s['qr_mime'])
        f = os.path.normpath(os.path.join(STATIC, p.lstrip('/') or 'index.html'))
        if not f.startswith(STATIC + os.sep) or not os.path.isfile(f): f = os.path.join(STATIC, 'index.html')
        with open(f, 'rb') as fh:
            self.send(200, fh.read(), mimetypes.guess_type(f)[0] or 'application/octet-stream')

    def api(self, m, p, q, c):
        P = p.split('/')
        if (m, p) == ('GET', 'config'): return self.send(200, pub_settings(c))
        if (m, p) == ('GET', 'me'):
            u = self.user(c); return self.send(200, {'user': dict(u) if u else None})
        if (m, p) == ('POST', 'register'):
            b = self.body()
            n = str(b.get('name', '')).strip()[:60]; e = str(b.get('email', '')).strip().lower()[:120]; pw = str(b.get('password', ''))
            if not n or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', e) or not 8 <= len(pw) <= 100:
                raise Err(400, 'Enter your name, a valid email and a password of 8+ characters')
            if c.execute('SELECT 1 FROM users WHERE email=?', (e,)).fetchone(): raise Err(409, 'This email is already registered')
            s = secrets.token_bytes(16)
            cur = c.execute('INSERT INTO users(name,email,salt,pw,created) VALUES(?,?,?,?,?)', (n, e, s, hp(pw, s), int(time.time())))
            return self.login_as(c, cur.lastrowid)
        if (m, p) == ('POST', 'login'):
            b = self.body(); e = str(b.get('email', '')).strip().lower(); pw = str(b.get('password', ''))[:100]
            now = time.time(); FAILS[e] = [t for t in FAILS.get(e, []) if now - t < 600]
            if len(FAILS[e]) >= 8: raise Err(429, 'Too many attempts. Please try again in a few minutes.')
            r = c.execute('SELECT * FROM users WHERE email=?', (e,)).fetchone()
            ok = hmac.compare_digest(hp(pw, r['salt'] if r else b'x' * 16), r['pw'] if r else 'x')
            if not r or not ok:
                FAILS[e].append(now); raise Err(401, 'Incorrect email or password')
            FAILS.pop(e, None)
            return self.login_as(c, r['id'])
        if (m, p) == ('POST', 'logout'):
            t = self.cookie('sid')
            if t: c.execute('DELETE FROM sessions WHERE token=?', (th(t),)); c.commit()
            return self.send(200, {'ok': True}, extra=self.ck('', 0))

        u = self.user(c)
        if not u: raise Err(401, 'Please log in')

        if (m, p) == ('GET', 'subjects'):
            return self.send(200, [r[0] for r in c.execute('SELECT DISTINCT subject FROM materials ORDER BY subject')])
        if (m, p) == ('GET', 'materials'):
            sql, a = 'SELECT * FROM materials WHERE 1=1', []
            if q.get('sem', '').isdigit(): sql += ' AND semester=?'; a.append(int(q['sem']))
            t = q.get('type')
            if t == 'pyq_mimp': sql += " AND type IN('pyq','mimp')"
            elif t in TYPES: sql += ' AND type=?'; a.append(t)
            for w in q.get('q', '').split()[:6]:
                sql += " AND (title||' '||subject||' sem '||semester) LIKE ?"; a.append('%' + w.replace('%', '').replace('_', '') + '%')
            st = {}
            for r in c.execute('SELECT mid,status FROM payments WHERE uid=? ORDER BY id', (u['id'],)):
                if st.get(r['mid']) != 'approved': st[r['mid']] = r['status']
            out = []
            for r in c.execute(sql + ' ORDER BY semester,subject COLLATE NOCASE,title COLLATE NOCASE', a):
                acc = allowed(c, u, r)
                out.append({'id': r['id'], 'semester': r['semester'], 'subject': r['subject'], 'title': r['title'], 'type': r['type'],
                            'price': r['price'], 'access': acc, 'status': 'approved' if acc else st.get(r['id'], 'locked')})
            return self.send(200, out)
        if m == 'GET' and len(P) == 3 and P[0] == 'materials' and P[2] == 'open':
            r = c.execute('SELECT * FROM materials WHERE id=?', (P[1],)).fetchone()
            if not r: raise Err(404, 'Not found')
            if not allowed(c, u, r): raise Err(403, 'Unlock this premium note first')
            return self.send(200, {'url': f"/files/{r['id']}" if r['file'] else r['link']})
        if (m, p) == ('POST', 'payments'):
            b = self.body(); txn = str(b.get('txn', '')).strip()
            r = c.execute("SELECT * FROM materials WHERE id=? AND type='premium'", (b.get('material_id'),)).fetchone()
            if not r: raise Err(404, 'Premium note not found')
            if not re.fullmatch(r'[A-Za-z0-9]{6,32}', txn): raise Err(400, 'Enter the UPI transaction / UTR ID (6-32 letters or digits)')
            if allowed(c, u, r): raise Err(409, 'You already have access')
            if c.execute("SELECT 1 FROM payments WHERE uid=? AND mid=? AND status='pending'", (u['id'], r['id'])).fetchone():
                raise Err(409, 'A payment for this note is already awaiting approval')
            if c.execute("SELECT 1 FROM payments WHERE lower(txn)=lower(?) AND status!='rejected'", (txn,)).fetchone():
                raise Err(409, 'This transaction ID was already submitted')
            c.execute('INSERT INTO payments(uid,mid,amount,txn,created) VALUES(?,?,?,?,?)', (u['id'], r['id'], r['price'], txn, int(time.time())))
            c.commit(); return self.send(200, {'ok': True})

        if P[0] != 'admin': raise Err(404, 'Not found')
        if not u['is_admin']: raise Err(403, 'Admin only')
        if (m, p) == ('GET', 'admin/materials'):
            return self.send(200, [{**dict(r), 'file': bool(r['file'])} for r in c.execute('SELECT * FROM materials ORDER BY semester,subject,title')])
        if (m, p) == ('POST', 'admin/materials'):
            b = self.body(); v = clean(b)
            f = save_pdf(b['file_b64']) if b.get('file_b64') else None
            if not v[5] and not f: raise Err(400, 'Add a Google Drive link or upload a PDF')
            cur = c.execute('INSERT INTO materials(semester,subject,title,type,price,link,file,created) VALUES(?,?,?,?,?,?,?,?)',
                            (*v[:5], v[5] or None, f, int(time.time())))
            c.commit(); return self.send(200, {'id': cur.lastrowid})
        if len(P) == 3 and P[1] == 'materials' and m in ('PUT', 'DELETE'):
            r = c.execute('SELECT * FROM materials WHERE id=?', (P[2],)).fetchone()
            if not r: raise Err(404, 'Not found')
            if m == 'DELETE':
                rm(r['file']); c.execute('DELETE FROM materials WHERE id=?', (r['id'],)); c.commit(); return self.send(200, {'ok': True})
            b = self.body(); v = clean(b); old = r['file']; f = old
            if b.get('remove_file'): f = None
            if b.get('file_b64'): f = save_pdf(b['file_b64'])
            if not v[5] and not f:
                if f and f != old: rm(f)
                raise Err(400, 'Keep a Drive link or a PDF')
            if old and f != old: rm(old)
            c.execute('UPDATE materials SET semester=?,subject=?,title=?,type=?,price=?,link=?,file=? WHERE id=?',
                      (*v[:5], v[5] or None, f, r['id']))
            c.commit(); return self.send(200, {'ok': True})
        if (m, p) == ('GET', 'admin/payments'):
            sql = ('SELECT p.id,p.amount,p.txn,p.status,p.created,u.name,u.email,m.title,m.subject,m.semester FROM payments p '
                   'JOIN users u ON u.id=p.uid JOIN materials m ON m.id=p.mid')
            a = []
            if q.get('status') in ('pending', 'approved', 'rejected'): sql += ' WHERE p.status=?'; a.append(q['status'])
            return self.send(200, [dict(r) for r in c.execute(sql + ' ORDER BY p.id DESC LIMIT 300', a)])
        if m == 'POST' and len(P) == 3 and P[1] == 'payments':
            act = self.body().get('action')
            if act not in ('approve', 'reject'): raise Err(400, 'Bad action')
            n = c.execute('UPDATE payments SET status=? WHERE id=?', ('approved' if act == 'approve' else 'rejected', P[2])).rowcount
            c.commit()
            if not n: raise Err(404, 'Not found')
            return self.send(200, {'ok': True})
        if (m, p) == ('GET', 'admin/settings'): return self.send(200, pub_settings(c))
        if (m, p) == ('PUT', 'admin/settings'):
            b = self.body(); new = {}
            for k in SK:
                if k in b: new[k] = str(b[k]).strip()[:300]
            if 'banner_on' in new: new['banner_on'] = '1' if new['banner_on'] == '1' else '0'
            for k in ('youtube', 'telegram'):
                if new.get(k) and not re.match(r'https?://\S+$', new[k], re.I): raise Err(400, f'{k.title()} link must start with http(s)://')
            if new.get('email') and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', new['email']): raise Err(400, 'Invalid contact email')
            if b.get('qr_b64'):
                raw = dec(b['qr_b64'], 3 * 1024 * 1024); mime = img_ok(raw, 'img')
                if not mime: raise Err(400, 'QR must be a PNG, JPG or WEBP image under 3 MB')
                with open(os.path.join(DATA, 'qr.bin'), 'wb') as f: f.write(raw)
                new['qr_mime'] = mime
            if b.get('qr_remove'): new['qr_mime'] = ''
            for k, v in new.items(): c.execute('INSERT INTO settings VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', (k, v))
            c.commit(); return self.send(200, pub_settings(c))
        raise Err(404, 'Not found')


if __name__ == '__main__':
    init()
    h, port = os.environ.get('HOST', '127.0.0.1'), int(os.environ.get('PORT', 8000))
    print(f'Pad Le Betaa GTU running at http://{h}:{port}')
    ThreadingHTTPServer((h, port), H).serve_forever()
