# Pad Le Betaa GTU — Your Ultimate GTU Study Partner

Full-stack site: Python 3.8+ standard library only (no installs), SQLite database, vanilla HTML/CSS/JS front end.

## Run
    ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='choose-a-strong-one' python3 server.py
    # open http://127.0.0.1:8000

On first start an admin account is created (if you skip ADMIN_PASSWORD, a random password is printed in the console).
Then log in -> **Admin** to: add/edit/delete notes (Drive link or PDF upload), set premium prices, approve payments, edit the banner, UPI ID/QR, and footer links.

## Deploy (any VPS / Render / Railway with a persistent disk)
    HOST=0.0.0.0 PORT=8000 SECURE_COOKIE=1 DATA_DIR=/persistent/path python3 server.py
Put it behind HTTPS (Caddy / nginx / platform TLS). `DATA_DIR` holds the database, uploaded PDFs and the QR image — back it up.

## How protection works
- Passwords: PBKDF2-SHA256 (200k rounds, per-user salt). Sessions: random token in an HttpOnly, SameSite=Lax cookie (only a hash is stored).
- All material listings need login. Premium links/PDFs are only returned by the server after the admin approves that student's payment.
- Premium PDFs are streamed through `/files/<id>` with a server-side check. Admin API is admin-only. Login attempts are rate limited.
- Payment flow: student pays via UPI/QR, submits the UTR ID -> admin checks the bank/UPI app -> Approve / Reject (can be revoked later).

Note: a Google Drive link is visible to a student once unlocked and could be shared; for stricter protection, upload the PDF instead.
